(function(exports) {
  'use strict';

  var Zoom = {
    key: 'user-hub.zoom',

    container: document.querySelector('.zoom-container'),

    selections: {
      normal: document.querySelector('.zoom-normal'),
      big: document.querySelector('.zoom-big'),
      bigger: document.querySelector('.zoom-bigger'),
      biggest: document.querySelector('.zoom-biggest')
    },

    setActive: function setActive(zoom) {
      Object.keys(this.selections).forEach(key =>
        this.selections[key].classList.remove('active'));
      this.selections[zoom || 'normal'].classList.add('active');
    },

    set: function(zoom) {
      this.setActive(zoom);
      var setting = {};
      setting[this.key] = zoom;
      navigator.mozSettings.createLock().set(setting);
    },

    init: function() {
      var req = navigator.mozSettings.createLock().get(this.key);
      req.onsuccess = () => this.setActive(req.result[this.key]);

      Object.keys(this.selections).forEach(selector => {
        this.selections[selector].addEventListener('click',
          e => this.set(e.target.dataset.zoom));
      });
    }
  };

  Zoom.init();

  exports.Zoom = Zoom;
})(window);
