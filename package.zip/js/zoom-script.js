/* globals console */

(function() {

  'use strict';

  var Zoom = {

    key: 'user-hub.zoom',

    multipliers: {
      normal: 1,
      big: 4/3,
      bigger: 5/3,
      biggest: 2
    },

    init: function init() {
      var req = navigator.mozSettings.createLock().get(this.key);
      req.onsuccess = () => this.set(req.result[this.key]);

      navigator.mozSettings.addObserver(this.key, event =>
        this.set(event.settingValue));
    },

    set: function(zoom) {
      zoom = zoom || 'normal';
      var multiplier = this.multipliers[zoom];
      var root = document.querySelector(':root');

      if (zoom === 'normal') {
        document.body.style.position = 'static';
        document.body.style.overflow = 'hidden';
        root.style.overflow = 'hidden';
      } else {
        document.body.style.position = 'relative';
        document.body.style.overflow = 'unset';
        root.style.overflow = 'unset';
      }
      document.body.style.transformOrigin = '0 0';
      document.body.style.transform = `scale3d(${multiplier}, ${multiplier})`;
    }
  };

  Zoom.init();

}());
