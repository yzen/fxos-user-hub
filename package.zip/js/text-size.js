(function(exports) {
  'use strict';

  var TextSize = {
    container: document.querySelector('.text-size-container'),
    smaller: document.querySelector('.text-size-smaller'),
    normal: document.querySelector('.text-size-normal'),
    bigger: document.querySelector('.text-size-bigger'),
    biggest: document.querySelector('.text-size-biggest'),

    setTextSize: function(textSize) {
      ['smaller', 'normal', 'bigger', 'biggest'].forEach(selector => {
        this[selector].classList.remove('active');
      });
      this[textSize].classList.add('active');
    }
  };

  ['smaller', 'normal', 'bigger', 'biggest'].forEach(selector => {
    TextSize[selector].addEventListener('click',
      e => TextSize.setTextSize(e.target.dataset.textSize));
  });

  exports.TextSize = TextSize;
})(window);
