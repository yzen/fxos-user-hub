/* global Settings */

(function(exports) {
  'use strict';

  function Select(options) {
    Settings.call(this, options.setting);
    this.selections = {};

    Object.keys(options.selections).forEach(name => {
      this.selections[name] = document.querySelector(options.selections[name]);
      this.selections[name].addEventListener('click', e => {
        var val = this.map(e.target.dataset.value);
        this.set(this.setting.name, val);
        this.select(val);
      });
    });
  }

  Select.prototype = Object.create(Settings.prototype);
  Select.prototype.select = function(val) {
    Object.keys(this.selections).forEach(name =>
      this.selections[name].classList.remove('active'));

    var active = Object.keys(this.selections).find(name =>
      this.map(this.selections[name].dataset.value) === this.map(val));
    this.selections[active || 'default'].classList.add('active');
  };
  Select.prototype.reset = function(val) {
    this.set(this.setting.name, val);
    this.select(val);
  };

  exports.Select = Select;
})(window);
