(function(exports) {
  'use strict';

  function ColorSwitch(setting, selector) {
    this.setting = setting;
    this.selector = selector;

    var req = navigator.mozSettings.createLock().get(this.setting);
    req.onsuccess = () => {
      var value = req.result[this.setting];
      if (value) {
        this.selector.setAttribute('checked', value);
      } else {
        this.selector.removeAttribute('checked');
      }
    };

    this.selector.addEventListener('change', () => {
      var settings = {};
      settings[this.setting] = this.selector.hasAttribute('checked');
      navigator.mozSettings.createLock().set(settings);
    });
  }

  var ColorFilter = {
    switches: {
      invert: new ColorSwitch('layers.effect.invert',
                              document.querySelector('.color-filter-invert')),
      grayscale: new ColorSwitch('layers.effect.grayscale',
                              document.querySelector('.color-filter-grayscale'))
    }
  };

  exports.ColorFilter = ColorFilter;
})(window);
